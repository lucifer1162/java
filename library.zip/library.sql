-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 16, 2019 at 06:19 PM
-- Server version: 10.4.6-MariaDB
-- PHP Version: 7.3.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `library`
--

-- --------------------------------------------------------

--
-- Table structure for table `book`
--

CREATE TABLE `book` (
  `book_id` int(15) NOT NULL,
  `book_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `book_author` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `book_pieces` varchar(25) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `book`
--

INSERT INTO `book` (`book_id`, `book_name`, `book_author`, `book_pieces`) VALUES
(1, 'Аквариум', 'Виктор Суворов', '2 ширхэг'),
(4, 'IT', 'Стивен Кинг', '2 ширхэг'),
(5, 'The Dark Tower: The Gunslinger', 'Стивен Кинг', '1 ширхэг'),
(6, 'Луун шивээст охин', 'Стиг Ларсон ', '5 ширхэг'),
(7, 'Harry Potter and the Philosopher\'s Stone', 'J. K. Rowling', '3 ширхэг'),
(8, 'Harry Potter and the Chamber of Secrets ', 'J. K. Rowling', '4 ширхэг'),
(9, 'Harry Potter and the Prisoner of Azkaban', 'J. K. Rowling', '6 ширхэг'),
(10, 'Harry Potter and the Goblet of Fire ', 'J. K. Rowling', '3 ширхэг'),
(11, 'Harry Potter and the Order of the Phoenix', 'J. K. Rowling', '1 ширхэг'),
(12, 'Harry Potter and the Half-Blood Prince', 'J. K. Rowling', '3 ширхэг'),
(15, 'Harry Potter', 'J.K.Rowling', '2-р ширхэг'),
(16, 'Harry Potter', 'J.K.Rowling', '5');

-- --------------------------------------------------------

--
-- Table structure for table `sex`
--

CREATE TABLE `sex` (
  `ID` int(5) NOT NULL,
  `Gender_name` varchar(15) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `sex`
--

INSERT INTO `sex` (`ID`, `Gender_name`) VALUES
(1, 'Эрэгтэй'),
(2, 'Эмэгтэй');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `User_ID` int(10) NOT NULL,
  `User_name` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `Fname` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `Lname` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `Sex` int(10) NOT NULL,
  `Birthday` date NOT NULL,
  `Password` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `Options` varchar(25) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`User_ID`, `User_name`, `Fname`, `Lname`, `Sex`, `Birthday`, `Password`, `Options`) VALUES
(3, 'user', 'bat', 'dorj', 1, '1444-11-13', 'user', 'User'),
(4, 'admin', 'admin', 'admin', 1, '1226-11-03', 'admin', 'Admin');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `book`
--
ALTER TABLE `book`
  ADD PRIMARY KEY (`book_id`);

--
-- Indexes for table `sex`
--
ALTER TABLE `sex`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`User_ID`),
  ADD UNIQUE KEY `User_name` (`User_name`),
  ADD KEY `Sex` (`Sex`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `book`
--
ALTER TABLE `book`
  MODIFY `book_id` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `sex`
--
ALTER TABLE `sex`
  MODIFY `ID` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `User_ID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `user`
--
ALTER TABLE `user`
  ADD CONSTRAINT `user_ibfk_1` FOREIGN KEY (`Sex`) REFERENCES `sex` (`ID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
